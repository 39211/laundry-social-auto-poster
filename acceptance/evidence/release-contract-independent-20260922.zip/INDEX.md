# Independent release-gate evidence

所有執行都使用合成 temp fixture；沒有真核准、部署、產品修補或平台請求。保留的來源快照與 adapters 不含憑證／真客戶媒體。已知私有值沒有寫入這些輸出；路徑為本機證據定位。

## 版本與結果

- 原五項基線：`release-contract-independent-20260922-r1.json`，2/5、exit 1。確切原始 gate SHA 在 `source-hashes.json` 的 before；基線 stdout/stderr/exit 完整保存。
- 原 oracle 假綠：`false-green-probe.mts` / `false-green-report.json`，5/5、exit 0。錯誤 adapter 只在 temp 改標題、錯日期，並刪除整份 daily/sitemap/服務頁。`mutation-observed.json` 與 `destructive-withdraw-observed.json` 留具體破壞證據。產品本體未改。
- R2 修正五項版：`r4-negative-report.json` 拒絕錯日期/舊 sitemap/舊服務頁；`r4-positive-fixed-report.json` 接受完整更新。原正向 adapter 曾誤取 sitemapEntries[0]（daily），`r4-positive-report.json` 與 diagnostic 證據保留，這是 reviewer harness 錯誤，不是產品缺陷；修正改按目標 URL 查找。
- R3 雙文章五項快照：`gate-r5-reviewed-source.ts` 與 `r5-source-manifest.json` 固定 a50bc7a…；`r5-negative-report.json` 拒絕刪整份 aggregate，`r5-positive-report.json` 接受只撤目標。
- `release-contract-independent-20260922-r5.json` 雖沿用預定 r5 檔名，執行時已載入主代理新增第六項，故實際 2/6。`r5-probe-summary.json` 明記來源變動。不得把它當作 a50bc7a… 的五項結果。
- 最終六項版：`gate-r6-reviewed-source.ts` SHA256 aa244fed66158d17543b748b08513f3d101fdab85bac671b1e1b31e3424cae3c。真產品 `release-contract-independent-20260922-r6.json` 2/6、exit 1；錯誤 adapter `r6-negative-report.json` 3/6、exit 1（R2/R3/R5 均 false）；正確 adapter `r6-positive-report.json` 6/6、exit 0。最新 typecheck exit 0。
- `r6-probe-summary.json` 記錄三跑各自磁碟 fixture 目錄 before/after 差異皆空、allocated=0。只有 README 在主代理更新實測基線；gate 與四個產品/fixture來源 SHA 未變。`final-source-manifest.json` 是最終檔案值。

## 重現與限制

在 site cwd 用 `node --import tsx acceptance/seo90ReleaseGate.ts --report 全新檔名.json` 跑原始基線。型別檢查：`node node_modules/typescript/bin/tsc --noEmit -p acceptance/tsconfig.json`。注入 adapter 只替換 temp 複本的 generate 邊界、import/報告位置，沒有改 oracle 斷言；每個 `.mts` 仍可在 site cwd 執行，須選全新 report 檔名。其路徑指向此機與 reviewer TEMP 證據目錄。

這些正向 adapters 只是 oracle 探測，不是產品 release writer。97 項預設測試不含本契約；本輪沒有重跑它。斷電、並行、共享圖片、部署、真核准未驗；不得外推可日更、可售或已發布。所有原始錯誤結果與 stdout/stderr/真正 exit code 均保留，沒有改寫為 PASS。
