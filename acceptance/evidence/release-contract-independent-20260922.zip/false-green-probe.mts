/**
 * Synthetic-only black-box contract for the actual public generator.
 * Exit 0: contract passed; 1: product gap; 2: harness/setup error.
 */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir,copyFile,writeFile,readFile,readdir,realpath,rm,access} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {basename,dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {preparePublicSeo90} from "file:///C:/Users/cyc39/Documents/AI_Agency/products/_coordination/sxj-seo90-20260922/site/src/seo90/publicBundle.ts";
import {digest} from "file:///C:/Users/cyc39/Documents/AI_Agency/products/_coordination/sxj-seo90-20260922/site/src/seo90/buildSeo90.ts";
import {makeSeo90Fixture} from "file:///C:/Users/cyc39/Documents/AI_Agency/products/_coordination/sxj-seo90-20260922/site/test/seo90Fixture.ts";
import type {Bundle} from "file:///C:/Users/cyc39/Documents/AI_Agency/products/_coordination/sxj-seo90-20260922/site/src/seo90/types.ts";

const repo="C:\\Users\\cyc39\\Documents\\AI_Agency\\products\\_coordination\\sxj-seo90-20260922\\site";
const baseUrl='https://sixiangjialaundry.com',now='2026-09-26T09:00:00+08:00';
const sentinelPath='unrelated-owner-sentinel.txt',sentinel='Unrelated owner content must remain intact.\n';
const marker='新版已核准內容標記';
type Row={id:string;passed:boolean;observed:Record<string,unknown>};
type Fixture={root:string;b:Bundle};
const allocated=new Set<string>();
const errorText=(e:unknown)=>(e instanceof Error?e.message:String(e)).slice(0,500);
async function exists(path:string){
 try{await access(path);return true;}catch(e){if((e as NodeJS.ErrnoException).code==='ENOENT')return false;throw e;}
}
async function text(root:string,path:string){
 const p=join(root,'docs',path);return await exists(p)?readFile(p,'utf8'):'';
}
async function snapshot(root:string){
 const result:Record<string,string>={};
 async function visit(path:string,prefix=''){
  for(const e of await readdir(path,{withFileTypes:true})){
   assert(!e.isSymbolicLink(),'Unexpected symlink in synthetic output');
   const rel=prefix+e.name;
   if(e.isDirectory())await visit(join(path,e.name),rel+'/');
   else if(e.isFile())result[rel]=createHash('sha256').update(await readFile(join(path,e.name))).digest('hex');
  }
 }
 await visit(join(root,'docs'));return result;
}
const differences=(a:Record<string,string>,b:Record<string,string>)=>[...new Set([...Object.keys(a),...Object.keys(b)])].filter(p=>a[p]!==b[p]).sort();
async function saveSource({root,b}:Fixture){
 const folder=join(root,'content','seo90');await mkdir(join(folder,'public-assets'),{recursive:true});
 for(let i=0;i<4;i++)await copyFile(join(root,i+'.png'),join(folder,'public-assets',i+'.png'));
 await writeFile(join(folder,'public-ready.json'),JSON.stringify({schemaVersion:'sxj.seo90.public-source.v1',bundle:b}));
}
const generate=async(root:string)=>{
 const input=JSON.parse(await readFile(join(root,'content/seo90/public-ready.json'),'utf8'));
 const a=input.bundle.articles[0];
 const articlePath=join(root,'docs',a.canonicalPath.slice(1));
 if(a.state==='withdrawn' && await exists(articlePath)) {
  const wholeFiles=['daily/index.html','sitemap.xml','services/shoe-bag-care.html'];
  const original=await Promise.all(wholeFiles.map(x=>text(root,x)));
  assert.equal(dirname(await realpath(root)).toLowerCase(),(await realpath(tmpdir())).toLowerCase());
  await rm(articlePath);
  for(const x of input.bundle.assets)await rm(join(root,'docs','seo90-assets',x.sha256+'.png'));
  for(const x of wholeFiles)await rm(join(root,'docs',x));
  await writeFile("C:\\Users\\cyc39\\AppData\\Local\\Temp\\seo90-release-gate-independent-20260922\\destructive-withdraw-observed.json",JSON.stringify({wholeFilesDeleted:wholeFiles,sitemapHadOtherUrl:original[1].split('<url>').length>2,serviceHadOtherContent:original[2].length>500,unrelatedSentinelPreserved:await text(root,sentinelPath)===sentinel},null,2));
  return;
 }
 if(a.title==='皮鞋遇雨，送洗前要拍哪些位置？' && await exists(articlePath))return;
 if(a.title===marker && await exists(join(root,'docs',a.canonicalPath.slice(1)))) {
  const article0=await text(root,a.canonicalPath.slice(1)),daily0=await text(root,'daily/index.html');
  const sitemap0=await text(root,'sitemap.xml'),service0=await text(root,'services/shoe-bag-care.html');
  const originalTitle='皮鞋遇雨，送洗前要拍哪些位置？';
  const updated=article0.split(originalTitle).join(marker).replace(/"datePublished"\s*:\s*"[^"]*"/g,'"datePublished":"2026-09-26T08:30:00+08:00"');
  await writeFile(join(root,'docs',a.canonicalPath.slice(1)),updated);
  await writeFile(join(root,'docs','daily/index.html'),daily0.split(originalTitle).join(marker));
  const fields=(s:string)=>Array.from(s.matchAll(/"date(?:Published|Modified)"\s*:\s*"[^"]*"/g),x=>x[0]);
  await writeFile("C:\\Users\\cyc39\\AppData\\Local\\Temp\\seo90-release-gate-independent-20260922\\mutation-observed.json",JSON.stringify({datesBefore:fields(article0),datesAfter:fields(updated),sitemapUnchanged:sitemap0===await text(root,'sitemap.xml'),sitemapOldDatePresent:sitemap0.includes(input.bundle.releases[0].datePublished),sitemapNewDatePresent:sitemap0.includes(input.bundle.releases[0].dateModified),serviceUnchanged:service0===await text(root,'services/shoe-bag-care.html'),serviceHasInitialArticle:service0.includes(a.canonicalPath),serviceHasNewTitle:service0.includes(marker),articleNewTitle:updated.includes(marker)},null,2));
  return;
 }
 return (await import("file:///C:/Users/cyc39/Documents/AI_Agency/products/_coordination/sxj-seo90-20260922/site/src/generatePublicSite.ts")).generatePublicSite({root,siteBaseUrl:baseUrl,now});
};
const prepare=(f:Fixture)=>preparePublicSeo90(f.b,{assetRoot:f.root,now,baseUrl,existingPaths:new Set(),existingIds:new Set()});
async function initial(f:Fixture){
 const a=f.b.articles[0]!,p=await prepare(f);
 assert(p.pages.some(x=>x.path===a.canonicalPath),'Initial fixture must be eligible');
 await saveSource(f);await generate(f.root);
 assert((await text(f.root,a.canonicalPath.slice(1))).includes(a.title),'Initial article missing');
 assert((await text(f.root,'daily/index.html')).includes(a.canonicalPath),'Initial daily link missing');
 assert((await text(f.root,'sitemap.xml')).includes(baseUrl+a.canonicalPath),'Initial sitemap entry missing');
 for(const x of f.b.assets)assert(await exists(join(f.root,'docs','seo90-assets',x.sha256+'.png')),'Initial asset missing');
 assert.equal(await text(f.root,sentinelPath),sentinel,'Unrelated content changed');
}
async function fixture<T>(run:(f:Fixture)=>Promise<T>):Promise<T>{
 const f=await makeSeo90Fixture(),absolute=await realpath(f.root),oldCwd=process.cwd();allocated.add(absolute);
 try{
  assert.equal(dirname(absolute).toLowerCase(),(await realpath(tmpdir())).toLowerCase(),'Fixture outside temp root');
  assert(basename(absolute).startsWith('seo90-'),'Unexpected fixture directory');
  await mkdir(join(f.root,'data'),{recursive:true});
  await copyFile(join(repo,'data','business-profile.json'),join(f.root,'data','business-profile.json'));
  await mkdir(join(f.root,'docs'),{recursive:true});await writeFile(join(f.root,'docs',sentinelPath),sentinel);
  process.chdir(f.root);return await run(f);
 }finally{
  process.chdir(oldCwd);
  // Confirm exact task-owned absolute target before recursive Windows cleanup.
  const current=await realpath(f.root);
  assert(allocated.has(current)&&current===absolute&&dirname(current).toLowerCase()===(await realpath(tmpdir())).toLowerCase(),'Cleanup target changed');
  await rm(current,{recursive:true,force:false});allocated.delete(current);
 }
}
async function attempt(root:string){try{await generate(root);return null;}catch(e){return errorText(e);}}
async function run():Promise<Row[]>{
 const rows:Row[]=[];
 await fixture(async f=>{
  await initial(f);
  rows.push({id:'R0_APPROVED_INITIAL_RELEASE',passed:true,observed:{article:true,daily:true,sitemap:true,assets:4,unrelatedPreserved:true}});
  const before=await snapshot(f.root),error=await attempt(f.root),after=await snapshot(f.root),changed=differences(before,after);
  rows.push({id:'R1_REPEAT_IS_NOOP',passed:error===null&&changed.length===0,observed:{error,changed}});
 });
 await fixture(async f=>{
  await initial(f);const a=f.b.articles[0]!;
  a.title=marker;f.b.approvals[0]!.articleSha256=digest(a);f.b.approvals[0]!.approvedAt='2026-09-26T08:00:00+08:00';
  f.b.releases[0]!.articleSha256=digest(a);f.b.releases[0]!.dateModified='2026-09-26T08:30:00+08:00';
  const proof=await prepare(f);assert(proof.pages.some(x=>x.path===a.canonicalPath&&x.bytes.toString().includes(marker)),'Update fixture is invalid');
  await saveSource(f);const error=await attempt(f.root);
  const articleUpdated=(await text(f.root,a.canonicalPath.slice(1))).includes(marker),dailyUpdated=(await text(f.root,'daily/index.html')).includes(marker),unrelatedPreserved=await text(f.root,sentinelPath)===sentinel;
  rows.push({id:'R2_APPROVED_UPDATE',passed:!error&&articleUpdated&&dailyUpdated&&unrelatedPreserved,observed:{error,articleUpdated,dailyUpdated,unrelatedPreserved}});
 });
 await fixture(async f=>{
  await initial(f);const a=f.b.articles[0]!;a.state='withdrawn';f.b.releases[0]!.state='withdrawn';
  await saveSource(f);const error=await attempt(f.root);
  const articleRemoved=!(await exists(join(f.root,'docs',a.canonicalPath.slice(1)))),dailyUnlinked=!(await text(f.root,'daily/index.html')).includes(a.canonicalPath),sitemapUnlinked=!(await text(f.root,'sitemap.xml')).includes(baseUrl+a.canonicalPath),serviceUnlinked=!(await text(f.root,'services/shoe-bag-care.html')).includes(a.canonicalPath);
  const remainingAssets=(await Promise.all(f.b.assets.map(x=>exists(join(f.root,'docs','seo90-assets',x.sha256+'.png'))))).filter(Boolean).length,unrelatedPreserved=await text(f.root,sentinelPath)===sentinel;
  rows.push({id:'R3_WITHDRAW_OWN_RELEASE',passed:!error&&articleRemoved&&dailyUnlinked&&sitemapUnlinked&&serviceUnlinked&&remainingAssets===0&&unrelatedPreserved,observed:{error,articleRemoved,dailyUnlinked,sitemapUnlinked,serviceUnlinked,remainingAssets,unrelatedPreserved}});
 });
 await fixture(async f=>{
  await initial(f);const before=await snapshot(f.root);
  f.b.articles[0]!.title='未重新核准的新內容'; // Deliberately retain old approval/release hashes.
  assert.equal((await prepare(f)).pages.length,0,'Stale-approval fixture unexpectedly eligible');
  await saveSource(f);const error=await attempt(f.root),after=await snapshot(f.root),changed=differences(before,after);
  rows.push({id:'R4_STALE_APPROVAL_PRESERVES_PUBLIC_TREE',passed:changed.length===0,observed:{error,changed}});
 });
 return rows;
}
async function main(){
 const args=process.argv.slice(2);
 assert(args.length===2&&args[0]==='--report'&&/^[a-zA-Z0-9_.-]+\.json$/.test(args[1]!),'Usage: tsx acceptance/seo90ReleaseGate.ts --report NAME.json');
 const path=join("C:\\Users\\cyc39\\AppData\\Local\\Temp\\seo90-release-gate-independent-20260922",args[1]!);await mkdir(dirname(path),{recursive:true});assert(!(await exists(path)),'Evidence exists; use a new report name');
 for(const key of Object.keys(process.env))if(key.endsWith('API_KEY'))delete process.env[key];
 process.env.PUBLIC_SITE_BASE_URL=baseUrl;
 globalThis.fetch=async()=>{throw new Error('Network forbidden in release contract probe');};
 let result:Record<string,unknown>,exit:number;
 try{
  const rows=await run(),passed=rows.filter(x=>x.passed).length;
  const sourceFiles=await Promise.all(['src/generatePublicSite.ts','src/seo90/publicBundle.ts','src/seo90/buildSeo90.ts','test/seo90Fixture.ts'].map(async path=>({path,sha256:createHash('sha256').update(await readFile(join(repo,path))).digest('hex')})));
  result={schemaVersion:'sxj.seo90.release-contract.v1',generatedAt:new Date().toISOString(),evaluationNow:now,syntheticOnly:true,sourceFiles,verdict:passed===rows.length?'GO_CONTRACT_ONLY':'NO_GO_RELEASE_RECONCILIATION',passed,total:rows.length,rows,remainingTempRoots:allocated.size,notCovered:['crash recovery','concurrent release writers','shared assets across multiple articles','deployment','real owner approval']};exit=passed===rows.length?0:1;
 }catch(e){result={verdict:'HARNESS_ERROR',error:errorText(e),remainingTempRoots:allocated.size};exit=2;}
 await writeFile(path,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({verdict:result.verdict,passed:result.passed,total:result.total,report:path,remainingTempRoots:allocated.size}));process.exitCode=exit;
}
main().catch(e=>{console.error(errorText(e));process.exitCode=2;});
